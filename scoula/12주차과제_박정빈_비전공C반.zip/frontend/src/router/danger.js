// export default [
//   {
//     path: '/danger/list',
//     name: 'danger/list',
//     component: () => import('../pages/danger/DangerListPage.vue'),
//   },
// ];
