import{_ as e,c,o as n}from"./index-C44BOmCo.js";const o={};function r(a,s){return n(),c("h1",null,"첫 번째 페이지")}const _=e(o,[["render",r]]);export{_ as default};
