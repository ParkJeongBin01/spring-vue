import{_ as e,c,o as r}from"./index-C44BOmCo.js";const t={};function n(o,a){return r(),c("h1",null,"첫 번째 페이지")}const _=e(t,[["render",n]]);export{_ as default};
