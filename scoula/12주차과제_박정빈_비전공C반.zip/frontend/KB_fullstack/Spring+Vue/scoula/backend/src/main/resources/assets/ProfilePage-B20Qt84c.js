import{_ as e,c,o}from"./index-C44BOmCo.js";const r={};function n(t,a){return o(),c("h1",null,"첫 번째 페이지")}const _=e(r,[["render",n]]);export{_ as default};
